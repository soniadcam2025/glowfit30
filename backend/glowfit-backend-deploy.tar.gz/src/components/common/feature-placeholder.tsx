"use client";

import { toast } from "sonner";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export function FeaturePlaceholder({
  title,
  description,
  actionLabel,
}: {
  title: string;
  description: string;
  actionLabel: string;
}) {
  return (
    <div className="space-y-4">
      <PageHeader title={title} description={description} />
      <Card className="space-y-3">
        <Input placeholder={`Update ${title.toLowerCase()}...`} />
        <Button onClick={() => toast.success(`${actionLabel} request queued`)}>
          {actionLabel}
        </Button>
      </Card>
    </div>
  );
}
