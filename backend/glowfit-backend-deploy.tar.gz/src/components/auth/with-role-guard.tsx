"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import type { Role } from "@/types";
import { useAuth } from "@/hooks/useAuth";

export function withRoleGuard<TProps extends object>(
  Component: React.ComponentType<TProps>,
  allowedRoles: Role[],
) {
  return function RoleGuardedComponent(props: TProps) {
    const router = useRouter();
    const { user, loading } = useAuth();

    useEffect(() => {
      if (!loading && (!user || !allowedRoles.includes(user.role))) {
        router.replace("/dashboard");
      }
    }, [loading, router, user]);

    if (loading || !user || !allowedRoles.includes(user.role)) return null;
    return <Component {...(props as TProps)} />;
  };
}
