import { cn } from "@/lib/utils";

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={cn(
        "w-full rounded-xl border border-border-soft bg-white/60 px-3 py-2 text-sm outline-none transition focus-ring dark:bg-slate-900/45",
        props.className,
      )}
    />
  );
}
