"use client";

import { Bell, LogOut, Menu } from "lucide-react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export function Topbar({
  onToggle,
}: {
  onToggle: () => void;
}) {
  const router = useRouter();
  const { user, logout: logoutAction } = useAuth();

  const logout = async () => {
    await logoutAction();
    router.push("/login");
  };

  return (
    <header className="glass sticky top-4 z-30 mb-5 flex h-16 items-center justify-between rounded-2xl px-4">
      <div className="flex items-center gap-2">
        <Button variant="ghost" onClick={onToggle} className="p-2">
          <Menu className="h-5 w-5" />
        </Button>
        <p className="text-sm text-slate-500">Admin Panel</p>
      </div>
      <div className="flex items-center gap-3">
        <button className="relative rounded-xl p-2 hover:bg-white/60 dark:hover:bg-slate-800/50">
          <Bell className="h-5 w-5" />
          <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-rose-500" />
        </button>
        <div className="rounded-xl bg-white/60 px-3 py-1 text-sm dark:bg-slate-800/50">
          {user?.name ?? "Admin"}
        </div>
        <Button variant="secondary" onClick={logout} className="gap-2">
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>
    </header>
  );
}
