"use client";

import { AuthProvider } from "@/store/auth-context";
import { AppQueryProvider } from "@/store/query-provider";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <AppQueryProvider>
      <AuthProvider>{children}</AuthProvider>
    </AppQueryProvider>
  );
}
