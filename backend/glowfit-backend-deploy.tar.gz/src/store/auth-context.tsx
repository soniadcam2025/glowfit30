"use client";

import { createContext, useContext, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { authService } from "@/services/auth.service";
import { hasApiBaseUrl } from "@/services/api";
import type { AuthUser, LoginPayload } from "@/types";

type AuthContextValue = {
  user: AuthUser | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (payload: LoginPayload) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["auth", "me"],
    queryFn: authService.me,
    retry: false,
    enabled: hasApiBaseUrl,
  });

  const value = useMemo<AuthContextValue>(
    () => ({
      user: data ?? null,
      loading: hasApiBaseUrl ? isLoading : false,
      isAuthenticated: !!data,
      login: async (payload) => {
        await authService.login(payload);
        await queryClient.invalidateQueries({ queryKey: ["auth", "me"] });
      },
      logout: async () => {
        await authService.logout();
        queryClient.clear();
      },
    }),
    [data, isLoading, queryClient],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
}
