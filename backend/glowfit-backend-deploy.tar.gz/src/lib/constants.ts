import type { LucideIcon } from "lucide-react";
import {
  Bell,
  Dumbbell,
  LayoutDashboard,
  Settings,
  Sparkles,
  Users,
  UtensilsCrossed,
} from "lucide-react";
import type { Role } from "@/types";

export type NavItem = { label: string; href: string; icon: LucideIcon };

export const adminNavItems: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Users", href: "/users", icon: Users },
  { label: "Workouts", href: "/workouts", icon: Dumbbell },
  { label: "Diet", href: "/diet", icon: UtensilsCrossed },
  { label: "Beauty", href: "/beauty", icon: Sparkles },
  { label: "Notifications", href: "/notifications", icon: Bell },
  { label: "Settings", href: "/settings", icon: Settings },
];

export const authCookieKey = "admin_token";
export const csrfCookieKey = "csrf_token";

export const routeRoleMap: Record<string, Role[]> = {
  "/dashboard": ["super_admin", "admin", "staff"],
  "/users": ["super_admin", "admin"],
  "/workouts": ["super_admin", "admin", "staff"],
  "/diet": ["super_admin", "admin", "staff"],
  "/beauty": ["super_admin", "admin", "staff"],
  "/notifications": ["super_admin", "admin"],
  "/settings": ["super_admin"],
};
