export type ApiError = {
  message: string;
  status?: number;
};

export type Role = "super_admin" | "admin" | "staff";

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  role: Role;
};

export type DashboardStats = {
  users: number;
  revenue: number;
  activity: number;
};

export type ChartPoint = {
  name: string;
  users: number;
  engagement: number;
};

export type DashboardPayload = {
  stats: DashboardStats;
  dailyUsers: ChartPoint[];
  engagement: ChartPoint[];
};

export type UserItem = {
  id: string;
  name: string;
  email: string;
  status: "active" | "blocked";
  joinedAt: string;
};

export type PaginatedResponse<T> = {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
};

export type LoginPayload = {
  email: string;
  password: string;
};

export type AuthResponse = {
  user: AuthUser;
};
