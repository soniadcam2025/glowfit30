"use client";

import { api } from "@/services/api";

export const contentService = {
  async saveWorkoutPlan(payload: unknown) {
    const { data } = await api.post("/workouts", payload);
    return data;
  },
  async saveDietPlan(payload: unknown) {
    const { data } = await api.post("/diet-plans", payload);
    return data;
  },
  async saveBeautyPost(payload: unknown) {
    const { data } = await api.post("/beauty/posts", payload);
    return data;
  },
  async sendNotification(payload: unknown) {
    const { data } = await api.post("/notifications/push", payload);
    return data;
  },
  async saveSettings(payload: unknown) {
    const { data } = await api.patch("/settings", payload);
    return data;
  },
};
