"use client";

import { api } from "@/services/api";
import type { ChartPoint, DashboardStats } from "@/types";

export const dashboardService = {
  async getStats() {
    const { data } = await api.get<DashboardStats>("/admin/stats");
    return data;
  },
  async getAnalytics() {
    const { data } = await api.get<{ dailyUsers: ChartPoint[]; engagement: ChartPoint[] }>(
      "/admin/analytics",
    );
    return data;
  },
};
