"use client";

import { api } from "@/services/api";
import type { AuthResponse, AuthUser, LoginPayload } from "@/types";

export const authService = {
  async login(payload: LoginPayload) {
    const { data } = await api.post<AuthResponse>("/auth/login", payload);
    return data;
  },
  async me() {
    const { data } = await api.get<AuthUser>("/auth/me");
    return data;
  },
  async logout() {
    await api.post("/auth/logout");
  },
};
