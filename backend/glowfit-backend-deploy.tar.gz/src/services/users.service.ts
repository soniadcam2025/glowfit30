"use client";

import { api } from "@/services/api";
import type { PaginatedResponse, UserItem } from "@/types";

type Query = { page: number; pageSize: number; search?: string; status?: string };

export const usersService = {
  async list(query: Query): Promise<PaginatedResponse<UserItem>> {
    const params = {
      ...query,
      status: query.status && query.status !== "all" ? query.status : undefined,
    };
    const { data } = await api.get<PaginatedResponse<UserItem>>("/users", { params });
    return data;
  },
  async getById(id: string) {
    const { data } = await api.get<UserItem>(`/users/${id}`);
    return data;
  },
  async block(id: string) {
    const { data } = await api.patch<UserItem>(`/users/${id}/block`);
    return data;
  },
};
