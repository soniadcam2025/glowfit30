"use client";

import axios from "axios";
import Cookies from "js-cookie";
import { csrfCookieKey } from "@/lib/constants";
import type { ApiError } from "@/types";

export const apiBaseUrl = process.env.NEXT_PUBLIC_API_URL?.trim();
export const hasApiBaseUrl = Boolean(apiBaseUrl);

export const api = axios.create({
  baseURL: apiBaseUrl,
  timeout: 12000,
  withCredentials: true,
});

api.interceptors.request.use((config) => {
  if (!hasApiBaseUrl) {
    return Promise.reject({
      message: "Missing NEXT_PUBLIC_API_URL. Set it in .env.local and restart dev server.",
      status: 500,
    } as ApiError);
  }
  const csrf = Cookies.get(csrfCookieKey);
  if (csrf) config.headers["x-csrf-token"] = csrf;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiError: ApiError = {
      message: error?.response?.data?.message || error?.message || "Something went wrong",
      status: error?.response?.status,
    };
    if (apiError.status === 401 && typeof window !== "undefined") {
      window.location.href = "/login";
    }
    return Promise.reject(apiError);
  },
);
