import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { authCookieKey } from "@/lib/constants";

export default async function Home() {
  const token = (await cookies()).get(authCookieKey)?.value;
  redirect(token ? "/dashboard" : "/login");
}
