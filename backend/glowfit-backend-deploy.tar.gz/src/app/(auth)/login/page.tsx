"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { hasApiBaseUrl } from "@/services/api";

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  const [email, setEmail] = useState("admin@glowfit.com");
  const [password, setPassword] = useState("admin123");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!hasApiBaseUrl) {
      toast.error("Set NEXT_PUBLIC_API_URL in .env.local, then restart the app.");
      return;
    }
    try {
      setLoading(true);
      await login({ email, password });
      toast.success("Logged in successfully");
      router.push("/dashboard");
    } catch (error) {
      toast.error((error as { message?: string })?.message ?? "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-blue-100 to-indigo-100 p-4 dark:from-slate-950 dark:to-slate-900">
      <Card className="glass-strong w-full max-w-md">
        <h1 className="text-2xl font-bold">Admin Login</h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Enter your credentials to continue.</p>
        <form onSubmit={onSubmit} className="mt-4 space-y-3">
          <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
          <Input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
          <Button disabled={loading} className="w-full">
            {loading ? "Signing in..." : "Sign in"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
