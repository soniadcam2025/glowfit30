"use client";

import { motion } from "framer-motion";
import dynamic from "next/dynamic";
import { StatCard } from "@/components/dashboard/stat-card";
import { PageHeader } from "@/components/common/page-header";
import { ChartSkeleton, EmptyState, ErrorState, StatCardsSkeleton } from "@/components/common/state";
import { useDashboardAnalytics, useDashboardStats } from "@/hooks/useDashboard";

const ChartCard = dynamic(() => import("@/components/dashboard/chart-card").then((m) => m.ChartCard), {
  ssr: false,
});

export default function DashboardPage() {
  const statsQuery = useDashboardStats();
  const analyticsQuery = useDashboardAnalytics();

  if (statsQuery.error || analyticsQuery.error) {
    return (
      <ErrorState message={(statsQuery.error || analyticsQuery.error)?.message ?? "Failed to load dashboard"} />
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
      <PageHeader title="Dashboard" description="Realtime growth and engagement overview" />
      {statsQuery.isLoading || analyticsQuery.isLoading ? (
        <>
          <StatCardsSkeleton />
          <section className="grid gap-4 xl:grid-cols-2">
            <ChartSkeleton />
            <ChartSkeleton />
          </section>
        </>
      ) : !statsQuery.data || !analyticsQuery.data ? (
        <EmptyState title="No dashboard data found" />
      ) : (
        <>
          <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            <StatCard label="Total Users" value={statsQuery.data.users.toLocaleString()} hint="+12% vs last week" />
            <StatCard
              label="Revenue"
              value={`$${statsQuery.data.revenue.toLocaleString()}`}
              hint="+8% vs last week"
            />
            <StatCard label="Activity Score" value={`${statsQuery.data.activity}%`} hint="+4% vs last week" />
          </section>
          <section className="grid gap-4 xl:grid-cols-2">
            <ChartCard
              title="Daily Users"
              data={analyticsQuery.data.dailyUsers}
              dataKey="users"
              stroke="#2563eb"
            />
            <ChartCard
              title="Engagement Trend"
              data={analyticsQuery.data.engagement}
              dataKey="engagement"
              stroke="#7c3aed"
            />
          </section>
        </>
      )}
    </motion.div>
  );
}
