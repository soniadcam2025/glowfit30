import { AppLoader } from "@/components/common/state";

export default function Loading() {
  return <AppLoader />;
}
