"use client";

import { useState } from "react";
import { toast } from "sonner";
import { withRoleGuard } from "@/components/auth/with-role-guard";
import { UsersTable } from "@/components/common/data-table";
import { PageHeader } from "@/components/common/page-header";
import { Pagination } from "@/components/common/pagination";
import { SearchFilterBar } from "@/components/common/search-filter-bar";
import { EmptyState, ErrorState, TableSkeleton } from "@/components/common/state";
import { ConfirmModal } from "@/components/ui/modal";
import { usePaginatedTable } from "@/hooks/usePaginatedTable";
import { useBlockUser, useUserDetails, useUsers } from "@/hooks/useUsers";
import type { UserItem } from "@/types";
import { Card } from "@/components/ui/card";

function UsersPage() {
  const table = usePaginatedTable();
  const [selected, setSelected] = useState<UserItem | null>(null);
  const [viewId, setViewId] = useState<string>();
  const usersQuery = useUsers(table.query);
  const blockMutation = useBlockUser(table.query);
  const userDetailQuery = useUserDetails(viewId);
  const total = usersQuery.data?.total ?? 0;
  const rows = usersQuery.data?.data ?? [];

  return (
    <div>
      <PageHeader title="Users Management" description="Search, filter and moderate app users" />
      <SearchFilterBar
        search={table.search}
        status={table.status}
        onSearchChange={(value) => {
          table.setSearch(value);
          table.setPage(1);
        }}
        onStatusChange={(value) => {
          table.setStatus(value);
          table.setPage(1);
        }}
      />
      {usersQuery.isLoading && <TableSkeleton />}
      {usersQuery.error && <ErrorState message={usersQuery.error.message} />}
      {!usersQuery.isLoading && !usersQuery.error && rows.length === 0 && (
        <EmptyState title="No users match current filters" />
      )}
      {!usersQuery.isLoading && !usersQuery.error && rows.length > 0 && (
        <>
          <UsersTable rows={rows} onView={(u) => setViewId(u.id)} onBlock={(u) => setSelected(u)} />
          <Pagination
            page={table.page}
            total={total}
            pageSize={table.pageSize}
            onChange={(page) => {
              table.setPage(page);
            }}
          />
        </>
      )}
      <ConfirmModal
        open={!!selected}
        title="Block this user?"
        onClose={() => setSelected(null)}
        onConfirm={async () => {
          if (!selected?.id) return;
          try {
            await blockMutation.mutateAsync(selected.id);
            toast.success(`User ${selected.name} blocked`);
            setSelected(null);
          } catch (error) {
            toast.error((error as { message?: string })?.message ?? "Failed to block user");
          }
        }}
      >
        This action can be reversed later from user profile settings.
      </ConfirmModal>
      <ConfirmModal open={!!viewId} title="User Details" onClose={() => setViewId(undefined)}>
        {userDetailQuery.isLoading && <p>Loading user details...</p>}
        {userDetailQuery.error && <p className="text-rose-500">{userDetailQuery.error.message}</p>}
        {userDetailQuery.data && (
          <Card className="mt-2 space-y-1 bg-transparent p-0 shadow-none">
            <p>Name: {userDetailQuery.data.name}</p>
            <p>Email: {userDetailQuery.data.email}</p>
            <p>Status: {userDetailQuery.data.status}</p>
          </Card>
        )}
      </ConfirmModal>
    </div>
  );
}

export default withRoleGuard(UsersPage, ["super_admin", "admin"]);
